#!/bin/bash



echo "Applying database migrations"
python3 manage.py migrate

echo "Starting server for local run"
exec newrelic-admin run-program gunicorn IHFR.wsgi:application --bind 0.0.0.0:9604 --workers 6 --worker-class=gthread --log-level=info --timeout 90

#echo "Starting server for production run"
#exec gunicorn IHFR.wsgi:application --bind 0.0.0.0:9604 --workers 6 --worker-class=gthread --threads 10 --log-level=info --timeout 90
