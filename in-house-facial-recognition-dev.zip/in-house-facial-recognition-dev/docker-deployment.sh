#!/bin/bash

# Run sh file using
# sh prod-deploy.sh
# chmod +x prod-deploy.sh

# Pull the Milvus Docker image
# Define the path to the host directory for persistent data storage
#HOST_DATA_DIR="/home/ubuntu/milvusdbdata/"
#
## Pull the latest Milvus image
#docker pull milvusdb/milvus:v2.1.1
#
## Stop and remove the existing Milvus container if it exists
#docker stop milvus 2>/dev/null || true
#docker rm milvus 2>/dev/null || true
#
## Run the Milvus container with a bind mount for persistent storage
#docker run -d --name milvus \
#  -p 19530:19530 \
#  -p 19121:19121 \
#  -v "$HOST_DATA_DIR:/var/lib/milvus" \
#  milvusdb/milvus:v2.1.1

# cd ./documentations/milvus
# sudo docker-compose down
# docker-compose up -d
# cd ../..

### BUILD & RUN IHFR

# Build the Docker image for ihfr

echo "DEPLOY_STEP 1 - Stopping & Building IHFR"
sudo docker stop ihfr
sudo docker rm -f ihfr
sudo docker build -t ihfr .

echo "DEPLOY_STEP 2 - Restarting Milvus"
sudo docker-compose -f ./documentation/milvus/docker-compose.yml down
sudo docker-compose -f ./documentation/milvus/docker-compose.yml up -d

# Run the ihfr container with host networking
echo "DEPLOY_STEP 3 - Restarting IHFR"
sudo docker run -d --network=host --gpus all \
-e environment=PRODUCTION \
-e model.path=/app/ \
-e NEW_RELIC_LICENSE_KEY=eu01xx070aa9bd586254840041ab77ccFFFFNRAL \
-e NEW_RELIC_APP_NAME="IHFR" \
--name ihfr ihfr

echo "DEPLOY_STEP 4 - Restarting Attu"
sudo docker stop attu
sudo docker rm -f attu
sudo docker run -d --network=host \
-e MILVUS_URL=127.0.0.1:19530 \
-e SERVER_PORT=19531 \
--name attu zilliz/attu:v2.4