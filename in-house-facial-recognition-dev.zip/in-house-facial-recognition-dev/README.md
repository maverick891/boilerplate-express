# IHFR

## Installation

### Docker Approach
```
> sudo docker build -t ihfr .
> sudo docker run --network=host ihfr
```

### With local model
```
download buffalo.zip and keep it unzipped in
repo/models/buffalo_l 
link: https://github.com/deepinsight/insightface/releases
```

### Test APIS
```
>>>> Test to Index Data
curl --location 'http://13.233.153.97:9604/apis/add_media_to_collection/' \
--header 'Content-Type: application/json' \
--data '{
    "media_url": "https://events-cdn.samaro.ai/events/2577/2178495435877968_1600.webp",
    "media_id": 2,
    "event_id": 1
}'

2nd media - https://events-cdn.samaro.ai/events/2577/1735043122835482349_1600.webp
3rd media - https://events-cdn.samaro.ai/events/2577/926662155732547_1600.webp
```

```
>>>> Test to Get Matching Medias
curl --location 'http://13.126.157.105:9604/apis/search_medias_by_image/' \
--header 'Content-Type: application/json' \
--data '{
    "selfie_media_url": "https://events-cdn.samaro.ai/prod-samaro/selfiePics/919425331581_1719210788774507990.jpeg",
    "event_id": 1
}'
```

### Local Approach

1. Clone the repository.

```commandline
sudo apt-get -y install python3.10
python3.10 -m virtualenv .

sudo apt update
sudo apt install -y build-essential python3-dev g++ cmake
sudo apt install -y libopenblas-dev libopencv-dev
```

2. Install the necessary Python libraries:
    ```bash
    pip install -r local-requirements.txt
    ```
3. Ensure MongoDB is running and accessible.

### ZILLIZ API DEBUGGING

```commandline
curl --request POST \
  --url https://in03-5efdb1eff95fb03.serverless.gcp-us-west1.cloud.zilliz.com/v2/vectordb/collections/list \
  --header 'accept: application/json' \
  --header 'authorization: Bearer 1405a9d7ebc5a93933563a05d89348d200969f36eeb93b516c03d7f6fc4131df28e1510fa5f0198229b27b93066761c41e82e995' \
  --data '{}'
```

### Attu
```
docker run -p 8000:3000 -e MILVUS_URL=127.0.0.1:19530 zilliz/attu:v2.4
```