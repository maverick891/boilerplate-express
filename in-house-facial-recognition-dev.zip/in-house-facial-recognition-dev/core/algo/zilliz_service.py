import requests

from IHFR.settings import ZILLIZ_CONFIG, ACTIVE_ENVIRONMENT
from core.apps import log


def zilliz_api_call(endpoint, method="POST", payload=None):
    """
    Generic function to interact with Zilliz Cloud API.
    :param endpoint: The endpoint of the Zilliz API (e.g., '/collections/list').
    :param method: HTTP method (POST, GET, etc.).
    :param payload: JSON payload for POST requests.
    :return: Parsed JSON response.
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {ZILLIZ_CONFIG.api_key}",
        "Content-Type": "application/json",
    }
    url = f"{ZILLIZ_CONFIG.base_url}{endpoint}"

    # log.info(f"Making {method} request to URL: {url} with payload: {payload}")

    try:
        if method == "POST":
            response = requests.post(url, json=payload, headers=headers)
        elif method == "GET":
            response = requests.get(url, params=payload, headers=headers)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")

        response.raise_for_status()
        log.info(f"Response from Zilliz API: {response.json()}")
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Zilliz API call failed: {e}")


def list_zilliz_collections():
    """
    Retrieve a list of all collections from Zilliz Cloud.
    """
    try:
        response = zilliz_api_call("/collections/list", method="GET")
        return response  # Should return a JSON with a key "collections"

    except RuntimeError as e:
        log.error(f"Error listing collections: {e}")
        raise


def get_or_create_collection_zilliz(event_id: int) -> str:
    """
    Get or create a collection in Zilliz Cloud for storing embeddings.
    Uses API calls instead of pymilvus methods.
    """
    collection_name = f"SAMARO_{ACTIVE_ENVIRONMENT}_event_all_media_{event_id}"

    try:
        # Check if collection already exists
        # collections = list_zilliz_collections().get("collections", [])
        # log.info(f"Checking for collection: {collection_name}")
        #
        # if collection_name in collections:
        #     log.info(f"Using existing collection: {collection_name}")
        # else:
        # Create collection if it doesn't exist
        payload = {
            "collectionName": collection_name,
            "dimension": 512,
            "vectorField": "vector",
            "metricType": "COSINE",
            # "fields": [
            #     {"name": "id", "type": "INT64", "isPrimaryKey": True},
            #     {"name": "vector", "type": "FLOAT_VECTOR", "params": {"dimension": 512}}
            # ],
        }
        # "description": f"Embedding storage for environment: {ACTIVE_ENVIRONMENT}",
        # log.info(f"Creating new collection with payload: {payload}")
        zilliz_api_call("/collections/create", method="POST", payload=payload)
        log.info(f"Created new collection: {collection_name}")
        return collection_name
    except RuntimeError as e:
        raise RuntimeError(f"Error while get/create collection {collection_name}: {e}")


def save_result_in_zilliz(event_id: int, media_id: int, embeddings: list) -> None:
    """
    Save embeddings to Zilliz Cloud using the collection API.
    """
    try:
        collection_name = get_or_create_collection_zilliz(event_id)

        payload = {
            "collectionName": collection_name,
            "data": [{"id": media_id, "vector": embedding} for embedding in embeddings],
        }

        # log.info(f"payload created to be saved in zilliz - {payload}")
        zilliz_api_call("/entities/insert", method="POST", payload=payload)
        log.info(f"Inserted media_id {media_id} into Zilliz collection.")
    except RuntimeError as e:
        raise RuntimeError(f"Error saving media_id {media_id} to Zilliz: {e}")


def fetch_from_zilliz_batch(embeddings_list: list, event_id: int) -> list:
    """
    Fetch similar media from Zilliz Cloud using the collection API.
    """
    try:
        collection_name = get_or_create_collection_zilliz(event_id)

        search_results = []
        for embeddings in embeddings_list:
            payload = {
                "collection_name": collection_name,
                "data": [embeddings],
                "anns_field": "vector",
                "params": {"metric_type": "COSINE", "params": {"nprobe": 10}},
                "limit": 5,
                "output_fields": ["id"],
            }

            response = zilliz_api_call(
                "/entities/search", method="POST", payload=payload
            )
            for result in response.get("results", []):
                for hit in result.get("hits", []):
                    if hit.get("distance") >= 0.3:
                        search_results.append(hit["entity"]["id"])

        log.info(f"Fetched matching images: {len(search_results)}")
        return search_results
    except RuntimeError as e:
        log.error(f"Error fetching embeddings from Zilliz: {e}")
        return []
