import boto3
import boto3
import json
import json

from IHFR.settings import AWS_CONFIG
from IHFR.settings import AWS_CONFIG

AWS_ACCESS_KEY_ID = AWS_CONFIG.access_key
AWS_SECRET_ACCESS_KEY = AWS_CONFIG.secret_key
QUEUE_URL = AWS_CONFIG.sqs_url
AWS_REGION = AWS_CONFIG.region

max_messages = 10
wait_time = 20


def fetch_all_messages_from_sqs(sqs, QUEUE_URL):
    all_messages = []
    while True:
        try:
            response = sqs.receive_message(
                QueueUrl=QUEUE_URL,
                MaxNumberOfMessages=max_messages,
                WaitTimeSeconds=wait_time
            )

            messages = response.get('Messages', [])
            if not messages:
                break  # No more messages available

            all_messages.extend(messages)

            print(f"Received {len(messages)} messages from SQS. Total collected: {len(all_messages)}")

        except Exception as e:
            print(f"Error fetching messages from SQS: {e}")
            break

    return all_messages


def process_message(message, sqs, QUEUE_URL):
    try:
        body = message['Body']
        order = json.loads(body)
        print(f"Processing message: {order}")
        # process_payload(order)

        receipt_handle = message['ReceiptHandle']
        sqs.delete_message(
            QueueUrl=QUEUE_URL,
            ReceiptHandle=receipt_handle
        )
        print(f"Deleted message with ReceiptHandle: {receipt_handle}")

    except Exception as e:
        print(f"Failed to process message with exception: {e}")


def send_message_to_sqs(message_body):
    sqs = boto3.client(
        'sqs',
        aws_access_key_id=AWS_CONFIG.access_key,
        aws_secret_access_key=AWS_CONFIG.secret_key,
        region_name=AWS_CONFIG.region
    )

    # Send the message to the SQS queue
    response = sqs.send_message(
        QueueUrl=AWS_CONFIG.sqs_url,
        MessageBody=json.dumps(message_body)
    )

    return response


try:
    print(f"Started reading!")

    sqs = boto3.client(
        'sqs',
        region_name=AWS_REGION,
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    )
    messages = fetch_all_messages_from_sqs(sqs, QUEUE_URL)
    for message in messages:
        process_message(message, sqs, QUEUE_URL)

except Exception as e:
    print(f"Main process failed with exception: {e}")
