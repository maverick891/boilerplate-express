from pymilvus import Collection, MilvusClient, connections

from IHFR import settings
from core.apps import log


class MilvusService:
    def __init__(self):
        """
        Initialize the Milvus service with connection settings.
        # if running local, docker should be properly initialized with milvus service running
        """
        connections.connect(
            "default",
            host=settings.MILVUS_CONFIG.host,
            port=settings.MILVUS_CONFIG.port,
            user=settings.MILVUS_CONFIG.username,
            password=settings.MILVUS_CONFIG.password,
        )
        self.client = MilvusClient(
            f"http://{settings.MILVUS_CONFIG.host}:{settings.MILVUS_CONFIG.port}",
            user=settings.MILVUS_CONFIG.username,
            password=settings.MILVUS_CONFIG.password
        )
        log.info("Successfully connected to Milvus!")

    def list_collections(self):
        """
        List all collections in the database like:
        [
            "SAMARO_UAT_event_all_media_1",
            "SAMARO_UAT_event_all_media_112",
            ...
        ]
        """
        return self.client.list_collections()
        # return utility.list_collections()

    def delete_collection(self, collection_name):
        """
        Delete a collection by name.
        """
        collection = Collection(name=collection_name)
        return collection.drop()

    def get_or_create_collection(self, collection_name):
        try:
            collection: Collection = Collection(collection_name)
        except:
            log.info(f"Creating new collection - {collection_name}")
            self.client.create_collection(
                collection_name=collection_name,
                dimension=512,
                vector_field_name="vector"
            )
            collection: Collection = Collection(collection_name)
            # schema = CollectionSchema(
            #     fields=[
            #         FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            #         FieldSchema(name="media_id", dtype=DataType.INT64),
            #         FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=512)
            #     ],
            #     description="Collection for storing vector embeddings"
            # )
            # collection: Collection = Collection(name=collection_name, schema=schema)
            # collection.create_index(
            #     field_name="vector",
            #     index_params={
            #         "metric_type": "COSINE",  # Choose COSINE for face recognition
            #         "index_type": "HNSW",  # Use HNSW for fast nearest-neighbor search
            #         "params": {"M": 16, "efConstruction": 200}  # Adjust for recall vs. speed
            #     }
            # )
            # log.info(f"Collection and Index created for collection {collection_name}")

        return collection

    def get_collection_stats(self, collection_name: str) -> dict:
        try:
            collection: Collection = Collection(name=collection_name)
            total_entities = collection.num_entities
            collection_size_mb = total_entities * 2056 / (1024 * 1024)  # bytes/row - 512 * 4 + 8
            payload = {
                "collection_name": collection_name,
                "total_entities": total_entities,
                "collection_size_mb": f'{collection_size_mb:.2f} MB'
            }

            log.info(f"Collection stats: {payload}")
            return payload
        except Exception as e:
            # payload = {   # DON'T - otherwise how will we know any exception raised?
            #     "collection_name": collection_name,
            #     "total_entities": 0,
            #     "collection_size_mb": '0 MB'
            # }
            raise RuntimeError(f"Error. - {e}")

    def insert_embeddings(self, collection_name: str, media_id: int, embeddings: list):
        """
        Insert embeddings into the specified collection.
        """
        collection: Collection = self.get_or_create_collection(collection_name)
        entities = [
            {
                "id": media_id,
                "vector": embedding
            } for embedding in embeddings
        ]
        result = collection.insert(data=entities)

        # media_ids = [media_id] * len(embeddings)  # Repeat media_id for each embedding
        # data = [media_ids, embeddings]  # ✅ Milvus expects a list of fields
        # result = collection.insert(data)
        # collection.flush()

        log.info(f"Inserted media_id {media_id} into Milvus collection: {collection.name} with {result}")
        return result

    def search_embeddings(self, query_embeddings: list, collection_name: str, threshold: float = 0.3) -> list:
        try:
            if not query_embeddings or not isinstance(query_embeddings, list) or not all(
                    isinstance(embed, list) for embed in query_embeddings):
                raise ValueError("query_embeddings must be a non-empty List[List[float]]")

            # Flatten if nested lists are detected
            query_embeddings = [item for sublist in query_embeddings for item in sublist] if isinstance(
                query_embeddings[0][0], list) else query_embeddings

            # if isinstance(query_embeddings[0], list) and not isinstance(query_embeddings[0][0], float):
            #     raise ValueError("Each embedding should be a flat list of floats")

            collection = self.get_or_create_collection(collection_name)
            # collection.load()

            search_params = {"metric_type": "COSINE", "params": {"nprobe": 10}}
            results = collection.search(
                data=query_embeddings,
                anns_field="vector",  # Ensure the field name matches your schema
                param=search_params,
                limit=4096,  # TODO⚠️ 4096 is too high; reduce it for better performance
                output_fields=["media_id"]  # Only include fields you want from the schema
            )

            # Process the results to get media_ids where the distance is below the threshold
            return [hit.id for hit in results[0] if hit.distance >= threshold]

            # matched_ids = [
            #     hit.media_id for hits in results for hit in hits if hit.distance >= threshold
            # ]
            # return matched_ids

        except Exception as e:
            raise RuntimeError(f"Milvus Error: {e}")
