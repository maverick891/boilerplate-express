import io

import cv2
import numpy as np
import requests
from PIL import Image
from django.core.files.uploadedfile import InMemoryUploadedFile

from IHFR import settings
from core.apps import log

# Initialize InsightFace model
model = None

import insightface
import onnxruntime as ort
import time


def get_insightface_model():
    global model

    # path = settings.MODEL_PATH if settings.ACTIVE_ENVIRONMENT != Environments.DEV else settings.BASE_DIR
    if model is None:
        log.info("Model is not loaded! Loading it now.")

        # Check available providers
        available_providers = ort.get_available_providers()
        log.info(f"Available providers - {available_providers}")

        # Determine which provider to use
        if 'CUDAExecutionProvider' in available_providers:
            log.info("CUDA is available. Using CUDAExecutionProvider.")
            providers = ['CUDAExecutionProvider']
        else:
            log.info("CUDA is not available. Falling back to CPUExecutionProvider.")
            providers = ['CPUExecutionProvider']

        model = insightface.app.FaceAnalysis(root=settings.MODEL_PATH, providers=providers)
        model.prepare(ctx_id=0, det_size=(640, 640))
    return model


def fetch_image(url, media_id):
    response = requests.get(url)
    image = Image.open(io.BytesIO(response.content))

    # Convert the image to a bytes-like object
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='JPEG')
    img_byte_arr = img_byte_arr.getvalue()  # Get the byte data

    return img_byte_arr


def convert_img_to_embeddings(image: bytes, media_id) -> list:
    """Convert image to embeddings using InsightFace."""
    image_cv = cv2.cvtColor(np.array(Image.open(io.BytesIO(image))), cv2.COLOR_RGB2BGR)
    # begin = time.time()
    faces = get_insightface_model().get(image_cv)
    embeddings = [face.normed_embedding.tolist() for face in faces]  # Use normalized embeddings for better accuracy
    # end = time.time()
    log.info(f"Embeddings for media id - {media_id} - {len(embeddings)}")
    # log.info(f"Embeddings created in {end-begin} s")
    return embeddings


def check_selfie_quality(image: InMemoryUploadedFile) -> object:
    """
    Evaluates the quality of a selfie based on clarity, brightness, and face positioning.
    """
    try:
        # Convert image bytes to OpenCV format
        image_cv = cv2.cvtColor(np.array(Image.open(image.file)), cv2.COLOR_RGB2BGR)
        faces = get_insightface_model().get(image_cv)

        if len(faces) != 1:
            raise RuntimeError("Exactly 1 face should be present!")

        # Get face coordinates with boundary checks
        face = faces[0]
        x1, y1, x2, y2 = map(int, face.bbox)
        h, w = image_cv.shape[:2]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)

        if (x2 <= x1) or (y2 <= y1):
            raise RuntimeError("Invalid face region detected")

        # Convert to LAB and extract face region
        lab_image = cv2.cvtColor(image_cv, cv2.COLOR_BGR2LAB)
        face_lab = lab_image[y1:y2, x1:x2]
        face_l_channel = face_lab[:, :, 0]  # L channel for face only

        BRIGHTNESS_SCALING = 1.315
        SHARPNESS_SCALING_FACTOR = 20.0

        # -------------------------------
        # Face-specific Brightness Calculation
        # -------------------------------
        aws_brightness = (np.mean(face_l_channel) / 255) * 100 * BRIGHTNESS_SCALING

        # -------------------------------
        # Face-specific Sharpness Calculation
        # -------------------------------
        def calculate_sharpness(channel):
            denoised = cv2.medianBlur(channel, 3)
            laplacian = cv2.Laplacian(denoised, cv2.CV_64F, ksize=3)
            return laplacian.var()

        sharpness = calculate_sharpness(face_l_channel)
        aws_sharpness = sharpness / SHARPNESS_SCALING_FACTOR

        # -------------------------------
        # Final Payload
        # -------------------------------
        payload = {
            'face_count': len(faces),
            'brightness': round(float(aws_brightness), 2),
            'sharpness': round(float(aws_sharpness), 2),
            '_debug': {
                'raw_lab_brightness': float(np.mean(face_l_channel)),
                'unscaled_brightness': float((np.mean(face_l_channel) / 255) * 100),
                'raw_sharpness': float(sharpness),
                'face_region': (int(x1), int(y1), int(x2), int(y2))
            }
        }

        log.info(f"Selfie analysis result - {payload}")
        return payload
    except Exception as e:
        log.error(e)
        return {}
