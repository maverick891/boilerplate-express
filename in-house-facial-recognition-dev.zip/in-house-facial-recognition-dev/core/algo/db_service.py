from IHFR import settings
from core.algo.milvus_service import MilvusService

if settings.ACTIVE_DB == "MILVUS":
    milvus_service = MilvusService()


def save_embedding(collection_name, media_id, embeddings):
    # if settings.ACTIVE_DB == Databases.ZILLIZ:
    #     return save_result_in_zilliz(collection_name, media_id, embeddings)
    # else:
    return milvus_service.insert_embeddings(
        collection_name=collection_name, media_id=media_id, embeddings=embeddings
    )


def get_matchings(embeddings_list: list, collection_name: str):
    # if settings.ACTIVE_DB == Databases.ZILLIZ:
    #     return fetch_from_zilliz_batch(embeddings_list, event_id)
    # else:
    return milvus_service.search_embeddings(embeddings_list, collection_name)


def delete_collection(collection_name):
    # if settings.ACTIVE_DB == Databases.MILVUS:
    return milvus_service.delete_collection(collection_name)


def get_collection_stats(collection_name):
    # if settings.ACTIVE_DB == Databases.MILVUS:
    return milvus_service.get_collection_stats(collection_name)


def list_all_collections():
    # if settings.ACTIVE_DB == Databases.MILVUS:
    return milvus_service.list_collections()
