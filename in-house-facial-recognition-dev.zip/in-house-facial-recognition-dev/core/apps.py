from django.apps import AppConfig

from utility.logging.logging import LogProject

app_name = "core"

log = LogProject.init_logger(app_name)


class CoreConfig(AppConfig):
    name = app_name

    def ready(self):
        from .algo.insightface_service import get_insightface_model
        get_insightface_model()
