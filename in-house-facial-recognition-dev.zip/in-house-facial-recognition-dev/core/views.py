import logging
from urllib.parse import urlparse, unquote

import psutil
from django.http import JsonResponse
from pymilvus import connections
from rest_framework import permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView

from core.algo import db_service
from core.algo.insightface_service import convert_img_to_embeddings, fetch_image, check_selfie_quality

log = logging.getLogger(__name__)


@permission_classes((permissions.AllowAny,))
@api_view(["GET"])
def health(request):
    try:
        try:
            milvus_status = "healthy" if connections.has_connection("default") else "unhealthy"
        except Exception as e:
            milvus_status = f"error: {str(e)}"

        cpu_usage = psutil.cpu_percent(interval=1)  # Get CPU usage in %
        memory_usage = psutil.virtual_memory().percent  # Get memory usage in %
        disk_usage = psutil.disk_usage('/').percent

        status = "healthy" if milvus_status == "healthy" and cpu_usage < 90 and memory_usage < 90 else "degraded"
        health_data = {
            "status": status,
            "milvus_status": milvus_status,
            "cpu_usage": f"{cpu_usage}%",
            "memory_usage": f"{memory_usage}%",
            "disk_usage": f"{disk_usage}%",
            "message": "Hello from IHFR. All systems operational!" if status == "healthy" else "Warning: Some systems are under high load or unhealthy.",
        }

        return JsonResponse(health_data, safe=False)

    except Exception as e:
        return JsonResponse({"status": "error", "message": f"Unexpected error: {str(e)}"}, safe=False, status=500)


class CollectionView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        """
        curl -X GET 'http://127.0.0.1:9604/ihfr/apis/stats/?query_for=all&collection_name=112'
        For single event - just change the query_for value to single
        """
        query_for = request.GET.get("query_for", None)
        collection_name = request.GET.get("collection_name", None)

        if query_for == 'all':
            payload = db_service.list_all_collections()
        else:
            payload = db_service.get_collection_stats(collection_name)

        return JsonResponse(payload, status=200, safe=False)

    def delete(self, request):
        try:
            collection_name = request.GET.get("collection_name", None)
            if collection_name is None:
                raise RuntimeError("Collection Name is required!")

            log.info(f"Deleting collection - {collection_name}")
            db_service.delete_collection(collection_name)
            return JsonResponse({"message": f"Collection deleted ", "collection_name": collection_name}, status=200)
        except Exception as e:
            raise RuntimeError(f'Failed to delete collection, {e}')


class SelfieView(APIView):
    def post(self, request):
        log.info("Checking selfie.")
        selfie_file = request.FILES.get("file", None)
        if not selfie_file:
            raise RuntimeError("Selfie file is required!")

        result = check_selfie_quality(selfie_file)
        return JsonResponse(data=result)


class IndexImagesView(APIView):
    def post(self, request):
        """
        For a unique media_id - the media_url will keep on changing, based on overwrites.
        """
        body = request.data

        media_url = body.get("media_url")
        media_id = int(body.get("media_id"))
        collection_name = body.get("collection_name")

        if not media_url or not collection_name or not media_id:
            raise RuntimeError(
                "'media_url' and 'collection_name', 'media_id' are required."
            )

        parsed_url = urlparse(media_url)
        file_path = unquote(parsed_url.path)
        if not file_path.lower().endswith((".jpg", ".jpeg", ".webp")):
            raise RuntimeError("Unsupported file type")

        log.info(f"Indexing new media - {body}")
        try:
            image = fetch_image(media_url, media_id)
            if image:
                embeddings = convert_img_to_embeddings(image, media_id)
                if embeddings:
                    db_service.save_embedding(collection_name, media_id, embeddings)
        except Exception as e:
            raise RuntimeError(f"Failed for {media_url} - {e}")
        return Response({"data": "Image submitted successfully."})


class FetchImagesView(APIView):
    def post(self, request):
        body = request.data
        log.info(f"Fetching image for - {body}")
        selfie_media_url = body.get("selfie_url")
        collection_name = body.get("collection_name")
        if not selfie_media_url or not collection_name:
            raise RuntimeError("Both 'selfie_media_url' and 'collection_name' are required.")

        image = fetch_image(selfie_media_url, selfie_media_url)
        parsed_url = urlparse(selfie_media_url)
        file_path = unquote(parsed_url.path)
        if not file_path.lower().endswith((".jpg", ".jpeg", ".webp")):
            raise RuntimeError("Unsupported file type")

        embeddings = convert_img_to_embeddings(image, 'selfie')
        try:
            matching_results = db_service.get_matchings(embeddings_list=embeddings, collection_name=collection_name)
        except:
            matching_results = []

        log.info(f"Found {len(matching_results)} matching medias.")
        return JsonResponse({"data": matching_results}, status=200)
