from django.urls import path

from .views import IndexImagesView, FetchImagesView, CollectionView, SelfieView, health

urlpatterns = [
    path('health/', health, name='health'),

    path('collection/', CollectionView.as_view(), name='CollectionView'),

    path('check_selfie/', SelfieView.as_view(), name='SelfieView'),
    path('add_media_to_collection/', IndexImagesView.as_view(), name='add_media_to_collection'),
    path('search_medias_by_image/', FetchImagesView.as_view(), name='search_medias_by_image'),
]
