from django.apps import AppConfig

from utility.logging.logging import LogProject

app_name = "utility"
log = LogProject.init_logger(app_name)


class UtilityConfig(AppConfig):
    name = app_name
