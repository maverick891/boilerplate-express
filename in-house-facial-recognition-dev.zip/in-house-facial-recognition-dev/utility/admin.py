from django.contrib import admin
from django.db.migrations.recorder import MigrationRecorder

admin.site.register(MigrationRecorder.Migration)
