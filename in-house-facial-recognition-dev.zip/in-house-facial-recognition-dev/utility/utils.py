from rest_framework import serializers

from utility.apps import log


class GenericSerializer(serializers.Serializer):
    # Define an empty dictionary or leave it as an empty tuple
    serializers.DictField()


def response_dict(data=None, msg="", stats={}, code=200, print_full_logs=False):
    """
    Usage - return JsonResponse(response_dict(data={}, code=200, print_full_logs=False))
    """
    response = {
        "meta": {"code": code, "message": msg, "data_statistics": stats},
        "data": data,
    }

    if print_full_logs:
        log.info("{}-{}".format(response["meta"], response["data"]))

    return response


def convert_to_dict(obj):
    return {key: value[0] for key, value in dict(obj).items()}
