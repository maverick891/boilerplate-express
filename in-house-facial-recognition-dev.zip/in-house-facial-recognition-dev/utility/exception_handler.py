import logging
import traceback

from rest_framework.exceptions import APIException
from rest_framework.views import exception_handler

from utility.apps import log


def custom_exception_handler(exc, context=None):
    """
    Class to wrap any unexpected non DRF exception into custom Unexpected Exception code
    REST_FRAMEWORK = {
        'EXCEPTION_HANDLER': 'utility.exception_handler.custom_exception_handler',
    }

    :param exc: Exception object
    :param context: Context object
    :return: None
    """

    if not isinstance(exc, APIException):
        s = ""
        for msg in exc.args:
            s += str(msg)
        exc = UnexpectedError(detail=s)
    tb = traceback.format_exc()
    logging.error(tb
        # "Custom exception handler caught the following error: {}. Traceback: {}".format(
        #     exc.detail, tb
        # )
    )
    response = exception_handler(exc, context)

    return response


class UnexpectedError(APIException):
    """
    Class for UnexpectedError Exception.
    Exception to be raised unsure about the exact cause of failure. Ex: RunTimeError
    """

    status_code = 500
    default_detail = "Unexpected Error occurred"
    default_code = "unexpected_error"


class CustomError(APIException):
    """
    Usage - raise CustomError()
    """

    status_code = 500
    default_detail = "Custom message"


class RuntimeErrorToBoth(RuntimeError):
    """
    1 - both user & internal dev - RuntimeErrorToBoth
    2 - not to user but to internal dev - RuntimeErrorInternalOnly
    3 - to user but not to internal dev - use RuntimeError asis default config
    """

    def __init__(self, user_message, internal_msg=""):
        from whatsapp_service.egress_services import (
            InternalNotification,
            notify_on_slack,
        )

        user_message = str(user_message)
        internal_msg = str(internal_msg)
        log.warn(internal_msg)

        notify_on_slack(
            channel=InternalNotification.Channels.TECH,
            data=InternalNotification.Text.FATAL_EXCEPTION.format(*[internal_msg]),
        )
        super().__init__(user_message)


class RuntimeErrorInternalOnly:
    def __init__(self, internal_msg: str, values_to_fill=None) -> None:
        from whatsapp_service.egress_services import (
            InternalNotification,
            notify_on_slack,
            send_emails_to_devs,
        )

        try:
            if values_to_fill:
                internal_msg = internal_msg.format(*values_to_fill)
            else:
                internal_msg = str(internal_msg)

            log.fatal(internal_msg)
            notify_on_slack(
                channel=InternalNotification.Channels.TECH, data=internal_msg
            )
        except Exception as e:
            log.fatal(e)
            send_emails_to_devs.delay(internal_msg, values_to_fill)

        return
