import cProfile
import io
import os
import pstats
import tempfile
import time

from django.conf import settings

try:
    PROFILE_LOG_BASE = settings.PROFILE_LOG_BASE
except:
    PROFILE_LOG_BASE = tempfile.gettempdir()


def profile(log_file):
    """Profile some callable.

    1. Import
    from utility.logging.profiling import profile

    2. Add decorator
    @profile("SubEventMediaView_get.prof")
    def get(self, request, event_sub_id):

    3. Check in logs_profiling folder.
    """

    if not os.path.isabs(log_file):
        log_file = os.path.join(PROFILE_LOG_BASE, log_file)

    def inner(func):
        def wrapper(*args, **kwargs):
            # Add a timestamp to the profile output when the callable
            # is actually called.
            (base, ext) = os.path.splitext(log_file)
            base = base + "-" + time.strftime("%Y%m%dT%H%M%S", time.gmtime())
            final_log_file = base + ext
            if not os.path.exists(PROFILE_LOG_BASE):
                os.makedirs(PROFILE_LOG_BASE)

            prof = cProfile.Profile()
            retval = prof.runcall(func, *args, **kwargs)
            prof.dump_stats(final_log_file)

            # write to txt directly.
            with open(final_log_file[:-5] + ".txt", "w") as f:
                ps = pstats.Stats(final_log_file, stream=f)
                ps.sort_stats("time", "calls")
                ps.print_stats(20)

            os.remove(final_log_file)
            return retval

        return wrapper

    return inner
