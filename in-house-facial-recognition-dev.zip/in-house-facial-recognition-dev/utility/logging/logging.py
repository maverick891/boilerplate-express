import logging
import logging.config
import os

from IHFR.settings import BASE_DIR


class LogProject:
    """
    Add in settings.py -
    from utility.logging.logging import LogProject
    LogProject.init_logger("app_name")

    Also Refer -
    -> getting the app name in logger - https://stackoverflow.com/a/33182047

    """

    @staticmethod
    def get_log_filepath():
        if not os.path.exists(str(BASE_DIR) + "/logs"):
            os.makedirs(str(BASE_DIR) + "/logs")
        return str(BASE_DIR) + "/logs/logs.log"

    def init_logger(log_class=__name__):
        config_file = str(BASE_DIR) + "/utility/logging/log_config.conf"
        log_path = LogProject.get_log_filepath()
        logging.config.fileConfig(
            config_file,
            defaults={"logfilename": log_path},
            disable_existing_loggers=False,
        )
        return logging.getLogger(log_class)
