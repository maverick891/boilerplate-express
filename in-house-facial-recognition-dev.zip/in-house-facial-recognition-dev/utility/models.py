from django.db import models


class BaseModel(models.Model):
    created_date = models.DateTimeField(
        auto_now_add=True, help_text="Created timestamp"
    )
    updated_date = models.DateTimeField(
        auto_now=True, help_text="Last updated timestamp"
    )

    # TODO - this needs to be well thought.
    # created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    # updated_by = models.CharField(max_length=255, blank=True, null=True)
    # is_deleted = models.CharField(max_length=36, blank=False, null=False, default='0')

    class Meta:
        abstract = True
