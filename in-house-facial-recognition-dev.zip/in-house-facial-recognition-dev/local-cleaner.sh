#!/usr/bin/bash

# should be run once a month to keep your local clean
# chmod +x local-cleaner.sh
# sh local-cleaner.sh

git add .
git stash clear
git stash save -m "before local cleaner"

git checkout master
git pull origin master
git branch --remotes -D $(git branch --remotes | grep -v 'origin/master')
git branch -D $(git branch)
git gc
git fetch --all

# docker
sudo docker system prune
