class Environments:
    DEV = "DEV"
    UAT = "UAT"
    PRODUCTION = "PRODUCTION"

class Databases:
    # MONGO = "MONGO"
    ZILLIZ = 'ZILLIZ'
    MILVUS = 'MILVUS'