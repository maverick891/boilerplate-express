# **Setup Local MongoDB for Facial Recognition System**

This guide explains how to install and configure MongoDB locally on a **Linux system** to store embeddings for the facial recognition system. By default, the system uses MongoDB Atlas, but you can run MongoDB locally using this guide.

---

## **1. Install MongoDB on Linux**

Follow these steps to install MongoDB Community Edition on your system.

### **Step 1: Import MongoDB Repository Key**
Run the following commands to add the MongoDB repository:

```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
