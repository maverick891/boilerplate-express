#!/bin/bash

# Run sh file using
# sh prod-deploy.sh
# chmod +x prod-deploy.sh

echo "DEPLOY_STEP 1 - Stopping & Building IHFR"
#mkdir venv
#cd venv
#python3 -m virtualenv .
#pip install -r requirements.txt
#python3 manage.py migrate
source venv_3.10/bin/activate
nohup env NEW_RELIC_APP_NAME="IHFR" environment="PRODUCTION" model.path="/app/" NEW_RELIC_LICENSE_KEY=eu01xx070aa9bd586254840041ab77ccFFFFNRAL \
    newrelic-admin run-program gunicorn IHFR.wsgi:application \
    --bind 0.0.0.0:9604 \
    --workers 6 \
    --worker-class=gthread \
    --log-level=info \
    --timeout 90 > gunicorn.log 2>&1 &

echo "DEPLOY_STEP 2 - Restarting Milvus"
sudo docker-compose -f ./documentation/milvus/docker-compose.yml down
sudo docker-compose -f ./documentation/milvus/docker-compose.yml up -d

## Run the ihfr container with host networking
#echo "DEPLOY_STEP 3 - Restarting IHFR"
#sudo docker run -d --network=host --gpus all \
#-e environment=PRODUCTION \
#-e model.path=/app/ \
#-e NEW_RELIC_LICENSE_KEY=eu01xx070aa9bd586254840041ab77ccFFFFNRAL \
#-e NEW_RELIC_APP_NAME="IHFR" \
#--name ihfr ihfr

echo "DEPLOY_STEP 4 - Restarting Attu"
sudo docker stop attu
sudo docker rm -f attu
sudo docker run -d --network=host \
-e MILVUS_URL=127.0.0.1:19530 \
-e SERVER_PORT=19531 \
--name attu zilliz/attu:v2.4