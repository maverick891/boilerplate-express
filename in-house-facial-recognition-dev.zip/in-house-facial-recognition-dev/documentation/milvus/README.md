docker setup 
- Pull the Milvus Docker image
  - docker pull milvusdb/milvus:v2.1.1

- Run the Milvus container
    - docker run -d --name milvus \
      -p 19530:19530 \
      -p 19121:19121 \
      milvusdb/milvus:v2.1.1

- Install Milvus SDK
    - pip install pymilvus
    
check milvus version in docker 
docker logs milvus-standalone | grep "Milvus" | grep "version"


# Milvus Standalone Installation (Without Docker)

This guide walks you through installing and running Milvus in standalone mode on your local system without using Docker.

---

## **System Requirements**
- **Operating System**: Ubuntu 20.04 (or compatible Linux distribution)
- **Memory**: Minimum 4GB (8GB recommended)
- **Disk Space**: At least 10GB free
- **CPU**: x86_64 architecture
- **Network**: Internet access for downloading dependencies

---

## **Step 1: Install Prerequisites**
Milvus requires several dependencies to be installed beforehand. Run the following commands to set up your environment:

### Install GCC
```bash
sudo apt update
sudo apt install -y build-essential
```

### Install CMake
```bash
sudo apt install -y cmake
```

### Install Python
Make sure Python 3.8 or later is installed.
```bash
sudo apt install -y python3 python3-pip
pip3 install --upgrade pip
```

### Install Go
Milvus requires Go for building.
```bash
sudo apt install -y golang
```

### Install etcd
```bash
wget https://github.com/etcd-io/etcd/releases/download/v3.5.6/etcd-v3.5.6-linux-amd64.tar.gz
tar -xvf etcd-v3.5.6-linux-amd64.tar.gz
sudo mv etcd-v3.5.6-linux-amd64/etcd* /usr/local/bin/
```

### Install MinIO
```bash
wget https://dl.min.io/server/minio/release/linux-amd64/minio
chmod +x minio
sudo mv minio /usr/local/bin/
```

### Install Protobuf
```bash
sudo apt install -y protobuf-compiler
```

---

## **Step 2: Download Milvus Source Code**
Clone the Milvus repository from GitHub:
```bash
git clone https://github.com/milvus-io/milvus.git
cd milvus
```

---

## **Step 3: Build Milvus**
1. Create a build directory:
   ```bash
   mkdir build && cd build
   ```

2. Configure the build using CMake:
   ```bash
   cmake ..
   ```

3. Compile Milvus:
   ```bash
   make -j$(nproc)
   ```

4. Once built, the binary will be located in the `bin/` directory.

---

## **Step 4: Configure Milvus**
Create a configuration file named `milvus.yaml` in the `bin` directory to specify paths for data, logs, and dependencies.

### Sample `milvus.yaml`:
```yaml
version: 2.0
dependencies:
  etcd:
    endpoints: ["localhost:2379"]
  minio:
    address: "localhost:9000"
    bucketName: "milvus"
    accessKeyID: "minioadmin"
    secretAccessKey: "minioadmin"
storage:
  path: "/var/lib/milvus/data"
logs:
  path: "/var/lib/milvus/logs"
```

---

## **Step 5: Start Dependencies**
1. **Start etcd**:
   ```bash
   etcd --advertise-client-urls http://localhost:2379 --listen-client-urls http://localhost:2379 &
   ```

2. **Start MinIO**:
   ```bash
   minio server /var/lib/minio &
   ```

---

## **Step 6: Start Milvus**
Navigate to the `bin` directory and start Milvus:
```bash
./milvus standalone
```
Milvus should now start and be accessible on `localhost:19530`.

---

## **Step 7: Test Milvus**
To ensure Milvus is running correctly, use the Python SDK to test the connection.

1. Install the SDK:
   ```bash
   pip3 install pymilvus
   ```

2. Create a Python script named `test_connection.py`:
   ```python
   from pymilvus import connections

   connections.connect("default", host="127.0.0.1", port="19530")
   print("Connection successful!")
   ```

3. Run the script:
   ```bash
   python3 test_connection.py
   ```

If the connection is successful, Milvus is set up correctly.

---

## **Step 8: Automate Startup (Optional)**
To automate the startup of etcd, MinIO, and Milvus, you can create a script or systemd service files.

---

## **Troubleshooting**
- Ensure all dependencies are installed correctly.
- Check the logs in `/var/lib/milvus/logs` for error messages.
- Verify that ports `2379` (etcd), `9000` (MinIO), and `19530` (Milvus) are not blocked by a firewall.

---

## **References**
- [Milvus Documentation](https://milvus.io/docs)
- [Milvus GitHub Repository](https://github.com/milvus-io/milvus)
